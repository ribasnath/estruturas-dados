#ifndef MINHA_ARVORE_AVL_HPP
#define MINHA_ARVORE_AVL_HPP

#include "MinhaArvoreDeBuscaBinaria.hpp"
#define nodoRaiz MinhaArvoreDeBuscaBinaria<T>::nodoRaiz
/**
 * @brief Representa uma árvore AVL.
 *
 * @tparam T O tipo de dado guardado na árvore.
 */
template <typename T>
class MinhaArvoreAVL final : public MinhaArvoreDeBuscaBinaria<T>
{
private:
    Nodo<T>* inseNew(T chave) {
        Nodo<T>* newNode = new Nodo<T>();
        newNode->chave = chave;
        newNode->altura = attAlt(newNode);
        nodoRaiz->altura = attAlt(nodoRaiz);
        //newNode = verificaRot(newNode);

        return newNode;
    };

    void inserirAux(Nodo<T>* node, T chave) {
        if (node == nullptr) {
            inseNew(chave);
        }
        else if (chave > node->chave) {
            if (node->filhoDireita == nullptr)
                node->filhoDireita = inseNew(chave);
            else {
                inserirAux(node->filhoDireita, chave);
                node = verificaRot(node);
            }
        }
        else if (chave < node->chave) {
            if (node->filhoEsquerda == nullptr)
                node->filhoEsquerda = inseNew(chave);
            else {
                inserirAux(node->filhoEsquerda, chave);
                node = verificaRot(node);
            }
        }
    };

    /*Nodo<T>* inserirAux(Nodo<T>* node, T chave) {
        if (node == nullptr) {
            return inseNew(chave);
        }
        else if (chave > node->chave) {
            if (node->filhoDireita == nullptr)
                node->filhoDireita = inserirAux(node->filhoDireita, chave);
            else
                inserirAux(node->filhoDireita, chave);
        }
        else if (chave < node->chave) {
            if (node->filhoEsquerda == nullptr)
                node->filhoEsquerda = inserirAux(node->filhoEsquerda, chave);
            else {
                inserirAux(node->filhoEsquerda, chave);
                node = verificaRot(node);
            }
        }
    };*/

    int attAlt(Nodo<T>* node) const {
        if (node == nullptr) return -1;
        else return std::max(attAlt(node->filhoEsquerda), attAlt(node->filhoDireita)) + 1;
    };

    Nodo<T>* simplesEsq(Nodo<T>* node) {
        Nodo<T>* nodeAux = node->filhoEsquerda;

        node->filhoEsquerda = nodeAux->filhoDireita;
        nodeAux->filhoDireita = node;

        return nodeAux;
    };

    Nodo<T>* simplesDir(Nodo<T>* node) {
        Nodo<T>* nodeAux = node->filhoDireita;

        node->filhoDireita = nodeAux->filhoEsquerda;
        nodeAux->filhoEsquerda = node;

        return nodeAux;
    };

public:
    ~MinhaArvoreAVL() {};
    MinhaArvoreAVL() {};

    

    void inserir(T chave) {
        if (nodoRaiz == nullptr) {
            Nodo<T>* newNode = new Nodo<T>{ chave, 0 };
            nodoRaiz = newNode;
        }
        else {
            inserirAux(nodoRaiz, chave);
            verificaRot(nodoRaiz);
        }
    };

    Nodo<T>* verificaRot(Nodo<T>* node) {
        if (node == nullptr)
            return nullptr;

        node->altura = attAlt(node);

        int fatorB = 0;
        int hE = 0, hD = 0;
        hD = attAlt(node->filhoDireita);
        hE = attAlt(node->filhoEsquerda);

        fatorB = hE - hD;

        if (fatorB < -1 && node->filhoEsquerda) {
            return simplesEsq(node);
        }
        else if (fatorB > 1 && node->filhoDireita) {
            return simplesDir(node);
        }
    };
};

#endif